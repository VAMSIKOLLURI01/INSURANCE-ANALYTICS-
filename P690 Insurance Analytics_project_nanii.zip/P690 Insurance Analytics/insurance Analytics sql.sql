use insurance;
select * from brokerage;
select * from fees;
select * from budgets;
select * from invoice;
select * from meeting;
select * from opportunity;
---------------------------------------------------------------------------------------
# KPI 1st : No of invoice by account executive
select 'Account Executive',income_class,count(income_class) from invoice 
group by income_class,'Account Executive';

-------------------------------------------------------------------------------------

# KPI 2nd : Yearly Meeting Count
select count(*) as "total meetings" from meeting;
SELECT YEAR(meeting_date) AS meeting_year, COUNT(*) AS count_year
FROM meeting
GROUP BY YEAR(meeting_date);
---------------------------------------------------------------------------------------
# KPI 4th : Stage funnel by revenue
select stage,sum(revenue_amount) from opportunity
group by stage;
----------------------------------------------------------------------------------------
# KPI 5th : No of meeting By Account Exe
DESCRIBE meeting;
SHOW COLUMNS FROM meeting;
SELECT 'Account Executive', COUNT('Account Executive') AS count_of_meeting_date 
FROM meeting 
GROUP BY 'Account Executive'
ORDER BY count_of_meeting_date DESC;

SELECT `Account Executive`, COUNT(`Account Executive`) AS count_of_meeting_date 
FROM meeting 
GROUP BY `Account Executive` 
ORDER BY count_of_meeting_date DESC;
---------------------------------------------------------------------------------------
# KPI 6th : Top open opportunity
select opportunity_name,sum(revenue_amount) from opportunity
group by opportunity_name order by sum(revenue_amount) desc limit 4;

# total opportunity
select count(opportunity_name) as Total_Opportunities from opportunity;
# open opportunity
select count(opportunity_name) as Open_Opportunities from opportunity
where stage="Propose Solution" or stage="Qualify Opportunity" ;

# total opportunity by product wise
select product_group,count(product_group) as total_opportunities_by_product_wise from opportunity
group by product_group;
----------------------------------------------------------------------------
# KPI 3.1 : cross sell(invoice)
select income_class ,sum(Amount) as Invoice from invoice  
where income_class in ('Cross Sell') 
group by income_class;

#KPI 3.1 : cross sell(Achieved)
(SELECT(
	SELECT  SUM(Amount)   FROM brokerage 
	where brokerage.income_class in ("Cross Sell"))
+ SUM(Amount) AS Achieved,income_class FROM fees where fees.income_class in ("Cross Sell") 
group by income_class);

----------------------------------------------------
#KPI 3.2 : new (invoice)
select income_class ,sum(Amount) as Invoice from invoice  
where income_class in ('New') 
group by income_class;

#KPI 3.2 : new (acheive)
SELECT
	(SELECT  SUM(Amount)  FROM brokerage where brokerage.income_class in ("New") ) +
							SUM(Amount) AS Achieved,income_class FROM fees 
                            where fees.income_class in ("New")
                            group by income_class ;
                            
----------------------------------------------------------------
#KPI 3.3 : Renewal (invoice)
select income_class ,sum(Amount) as Invoice from invoice  
where income_class in ('Renewal') 
group by income_class;

#KPI 3.3 : Renewal (Achieved)
SELECT
	(SELECT  SUM(Amount)  FROM brokerage where brokerage.income_class in ("Renewal") ) +
							SUM(Amount) AS Achieved,income_class FROM fees 
                            where fees.income_class in ("Renewal")
                            group by income_class ;

--------------------------------------------------------------------------
